# Loader and whitelist API for Vercel

This is the Vercel-only loader, whitelist, artifact, and ticket authority. Its realtime gateway remains on Render at the `REALTIME_WS_URL` value. Set every key from `.env` as an encrypted Production Vercel environment variable before deployment.

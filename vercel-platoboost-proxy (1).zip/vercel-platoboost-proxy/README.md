# Platoboost API proxy — Vercel

ชุด backend พร้อมอัปโหลดขึ้น GitHub แล้ว Import ไป Deploy บน Vercel ใช้ Vercel Serverless Functions และไม่ต้องติดตั้ง dependency เพิ่ม

**เก็บ `PLATOBOOST_SERVICE` และ `PLATOBOOST_SECRET` ไว้บน Vercel เท่านั้น** ส่วน `SCRIPT_ID` เป็น ID สาธารณะตามที่ต้องการ จึงกำหนดไว้ฝั่ง Roblox/client ในรูปแบบ `script_...`

## โครงสร้างไฟล์

```text
vercel-platoboost-proxy/
├── api/
│   ├── health.js
│   ├── start.js
│   ├── redeem.js
│   └── whitelist.js
├── lib/
│   ├── http.js
│   └── platoboost.js
├── .env.example
├── .gitignore
├── package.json
├── client-example.lua
└── README.md
```

## Deploy จาก GitHub ไป Vercel

### 1. สร้าง repository บน GitHub

1. ดาวน์โหลด ZIP แล้วแตกไฟล์
2. ใน GitHub กด **New repository** ตั้งชื่อ เช่น `platoboost-vercel-api`
3. เลือก **Add file → Upload files** แล้วอัปโหลดไฟล์และโฟลเดอร์ *ข้างใน* ที่แตกออกมา
4. ตรวจว่า `api/`, `lib/` และ `package.json` อยู่ที่ root ของ repository ไม่ได้ซ้อนอยู่ในโฟลเดอร์อีกชั้น
5. กด **Commit changes**

### 2. Import repository เข้า Vercel

1. ใน Vercel เลือก **Add New → Project**
2. เลือก **Import Git Repository** แล้วเลือก repository ที่สร้างไว้
3. ตั้ง Root Directory เป็น `./` และ Framework Preset เป็น **Other** หากมีตัวเลือก
4. เพิ่ม Environment Variables ต่อไปนี้ใน Vercel:

| Name | ใส่ค่า |
|---|---|
| `PLATOBOOST_SERVICE` | Service ID จากบัญชี Platoboost |
| `PLATOBOOST_SECRET` | Secret ใหม่/ปัจจุบันจาก Platoboost — ห้ามเปิดเผย |

ตั้งค่าให้ครอบคลุม Environment ที่จะใช้งาน แล้วกด **Deploy** หากแก้ Environment Variables ภายหลัง ให้สั่ง **Redeploy** ด้วย

### 3. ตรวจ Deploy

เปิด URL นี้ในเบราว์เซอร์:

```text
https://ชื่อโปรเจกต์ของคุณ.vercel.app/api/health
```

ควรได้ `{"ok":true}`

## Lua / Roblox client

แก้ `API_BASE` ใน `client-example.lua` ให้เป็น URL ของโปรเจกต์ Vercel แล้วกำหนด Script ID ฝั่ง Roblox โดยให้ขึ้นต้นด้วย `script_` เช่น:

```lua
local API_BASE = "https://ชื่อโปรเจกต์ของคุณ.vercel.app/api"
local SCRIPT_ID = "script_a1b2c3d4"
```

ใช้ Script ID ค่าเดิมอย่างคงที่สำหรับสคริปต์นั้น อย่าสุ่มใหม่ทุก request เพราะ identifier จะเปลี่ยน

ทุก endpoint รับเฉพาะ `POST` พร้อม JSON:

- `POST /api/start` — `{"hwid":"...","scriptId":"script_a1b2c3d4"}`
- `POST /api/redeem` — `{"hwid":"...","scriptId":"script_a1b2c3d4","key":"..."}`
- `POST /api/whitelist` — `{"hwid":"...","scriptId":"script_a1b2c3d4","key":"..."}`

ตัวอย่างทดสอบ `start`:

```bash
curl -X POST "https://ชื่อโปรเจกต์ของคุณ.vercel.app/api/start" \
  -H "Content-Type: application/json" \
  -d '{"hwid":"test-user","scriptId":"script_a1b2c3d4"}'
```

ตัวอย่าง client ใช้ `HttpService:JSONEncode` / `JSONDecode` และส่ง key ใน `POST` body แทน query string เพื่อไม่ใส่ key ไว้ใน URL โปรเจกต์นี้จึงไม่ต้องฝัง JSON/SHA256 library ยาว ๆ ใน Lua และโค้ดหลักวางต่อท้ายได้ตามปกติ ไม่ต้องครอบ main code ทั้งก้อนใน function

## ความปลอดภัยและข้อจำกัด

- อย่า commit `.env`, Service Secret หรือ key จริงขึ้น GitHub; `.gitignore` กันไฟล์ `.env` ไว้แล้ว
- `PLATOBOOST_SERVICE` และ `PLATOBOOST_SECRET` อยู่บน Vercel; `SCRIPT_ID` อยู่ฝั่ง Roblox/client ตามที่ต้องการ โดย Script ID ไม่ใช่ Secret
- API URL และ Script ID เป็นข้อมูลที่ client มองเห็นได้ การซ่อน Service ID/Secret ไม่ได้ทำให้ endpoint เป็นส่วนตัว ควรเพิ่ม rate limiting หากเปิดใช้สาธารณะ
- `hwid` มาจาก client จึงปลอมแปลงได้ อย่าถือว่าเป็นตัวตนที่ยืนยันแล้ว
- ไม่มีระบบ key ฝั่ง client ใดป้องกันการคัดลอกหรือแก้สคริปต์ได้สมบูรณ์

> หากค่า Secret ที่เคยอยู่ในแชตเป็นของจริง ให้เปลี่ยน/ออก Secret ใหม่ใน Platoboost ก่อนใช้งาน

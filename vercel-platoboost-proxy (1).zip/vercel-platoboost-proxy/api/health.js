import { sendJson } from '../lib/http.js';

export default function handler(req, res) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    return sendJson(res, 405, { ok: false, message: 'Use GET.' });
  }

  return sendJson(res, 200, { ok: true });
}

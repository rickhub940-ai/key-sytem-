import { readJsonBody, requirePost, sendJson, stringField } from '../lib/http.js';
import { getConfig, makeIdentifier, pbStart } from '../lib/platoboost.js';

export default async function handler(req, res) {
  if (!requirePost(req, res)) return;

  const body = readJsonBody(req);
  if (!body) {
    return sendJson(res, 400, { success: false, message: 'Expected a JSON request body.' });
  }

  const hwid = stringField(body, 'hwid', 256);
  const scriptId = stringField(body, 'scriptId', 100);
  if (!hwid || !scriptId || !scriptId.startsWith('script_')) {
    return sendJson(res, 400, { success: false, message: 'Provide a valid hwid and scriptId starting with script_.' });
  }

  let config;
  try {
    config = getConfig();
  } catch (error) {
    console.error('[api/start] Configuration error:', error.message);
    return sendJson(res, 500, { success: false, message: 'Server configuration is incomplete.' });
  }

  try {
    // Script ID is a public client-side identifier; the Platoboost service ID stays server-side.
    const identifier = makeIdentifier(hwid, scriptId);
    const result = await pbStart(config.service, identifier);
    return sendJson(res, result.status, result.body);
  } catch (error) {
    console.error('[api/start] Provider request failed:', error.message);
    return sendJson(res, 502, { success: false, message: 'Key provider is unavailable.' });
  }
}

import { readJsonBody, requirePost, sendJson, stringField } from '../lib/http.js';
import {
  createNonce,
  getConfig,
  makeIdentifier,
  pbRedeem,
  verifySignedValidResponse,
} from '../lib/platoboost.js';

export default async function handler(req, res) {
  if (!requirePost(req, res)) return;

  const body = readJsonBody(req);
  if (!body) {
    return sendJson(res, 400, { success: false, message: 'Expected a JSON request body.' });
  }

  const hwid = stringField(body, 'hwid', 256);
  const scriptId = stringField(body, 'scriptId', 100);
  const key = stringField(body, 'key', 512);
  if (!hwid || !scriptId || !scriptId.startsWith('script_') || !key) {
    return sendJson(res, 400, { success: false, message: 'Provide valid hwid, scriptId starting with script_, and key.' });
  }

  let config;
  try {
    config = getConfig();
  } catch (error) {
    console.error('[api/redeem] Configuration error:', error.message);
    return sendJson(res, 500, { success: false, message: 'Server configuration is incomplete.' });
  }

  try {
    const identifier = makeIdentifier(hwid, scriptId);
    const nonce = createNonce();
    const result = await pbRedeem(config.service, identifier, key, nonce);

    if (
      result.status >= 200 && result.status < 300 &&
      result.body?.success === true && result.body?.data?.valid === true &&
      !verifySignedValidResponse(result.body, nonce, config.secret)
    ) {
      return sendJson(res, 502, {
        success: false,
        data: { valid: false },
        message: 'Key provider response failed integrity verification.',
      });
    }

    return sendJson(res, result.status, result.body);
  } catch (error) {
    console.error('[api/redeem] Provider request failed:', error.message);
    return sendJson(res, 502, { success: false, message: 'Key provider is unavailable.' });
  }
}

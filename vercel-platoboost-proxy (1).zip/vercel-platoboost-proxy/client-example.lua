-- Example client calls for the Vercel API.
-- Keep PLATOBOOST_SERVICE and PLATOBOOST_SECRET on Vercel only.
-- SCRIPT_ID is a public identifier configured on the Roblox/client side.

local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")

local API_BASE = "https://YOUR-PROJECT.vercel.app/api"
local SCRIPT_ID = "script_a1b2c3d4" -- choose a stable value beginning with script_
local httpRequest = request or http_request or syn_request
local HWID = tostring(gethwid and gethwid() or Players.LocalPlayer.UserId)

local function apiPost(path, payload)
    if not httpRequest then
        warn("This client does not provide an HTTP request function")
        return nil
    end

    local ok, response = pcall(httpRequest, {
        Url = API_BASE .. path,
        Method = "POST",
        Headers = { ["Content-Type"] = "application/json" },
        Body = HttpService:JSONEncode(payload)
    })

    if not ok or not response or not response.Body then
        warn("Could not reach the Vercel API")
        return nil
    end

    local decoded, data = pcall(function()
        return HttpService:JSONDecode(response.Body)
    end)
    if not decoded then
        warn("The Vercel API returned invalid JSON")
        return nil
    end

    return data, response.StatusCode
end

-- Request the user's key link:
local startResult = apiPost("/start", {
    hwid = HWID,
    scriptId = SCRIPT_ID
})
if startResult and startResult.success and startResult.data then
    print("Key link response received")
end

-- Check a key (call this after the user enters a key):
-- local key = "USER_ENTERED_KEY"
-- local verifyResult = apiPost("/whitelist", {
--     hwid = HWID,
--     scriptId = SCRIPT_ID,
--     key = key
-- })
-- if verifyResult and verifyResult.success and verifyResult.data and verifyResult.data.valid then
--     print("Key passed")
--     -- Main code can continue here at top level; it need not be wrapped in a function.
-- else
--     warn("Key is invalid")
-- end
